INSERT INTO `triple_agreement` VALUES (1, '31801093', '沈钰琦', 'J02', '蔡建平', 0000000001, '1', 0000000000);
INSERT INTO `triple_agreement` VALUES (2, '31801150', '张帅', 'J02', '蔡建平', 0000000001, '4', 0000000000);
